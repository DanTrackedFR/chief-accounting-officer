# Independent release-governance bounded preflight review

Reviewer: fresh `release_preflight_review` agent; no implementation work. Read-only repository review on 2026-11-07. Candidate `ecf4bb8907b5a7a45e6f59bc3d129d6dbf69cd4c`, tree `ff24a0b6362eeab796c9b49ea6be3a2f4f706fee`; main `97d0621331c6ad2a66b12ed09c0ec40c05c626b9`.

**Conclusion: BLOCKED before full regression. This is preflight review, not independent release acceptance. No full regression or GitHub artifact acceptance is claimed.**

## Independently verified findings

1. `.github/workflows/cao-presumed-sources.yml` compares fresh `prove_presumed_http` output to immutable `skills/presumed-sources/release/http-proof.json` before dispatching expensive regression. Actual source109/source971 outputs are byte-identical and differ from historical reference at exactly `/executions/0/public_sha256` and `/executions/1/public_sha256`. The historical reference remains exact accepted-main Git blob. No versioned Phase A proof-selection contract exists in this workflow. Replacing the historical expected proof would violate preservation. The digest-only proof must also expose or bind the structured fields needed to challenge corrected API values, rather than treating new hashes alone as accounting verification.

2. Independent economics recalculation from the proof fixture (`hosted_cao/tests/test_presumed_engineering_qa.py:synthetic_case`) gives 27 asset costs SUM(10000+1000*i,i=1..27)=648000; zero opening accumulated/residual, ten-year remaining life, full calendar 2026 actual-day charge64800; closing accumulated64800. Ten AP invoices SUM(100+10*i,i=1..10)=1550. Current and historical calculation arrays, check-count arrays and all other proof JSON fields agree. This validates unchanged numerical fields in this proof only, not every new Phase A scenario.

3. Actual runner preflight retained logs show mandatory suites17/19/20 pass19+18+12=49 methods. Suites18 and21 fail in setUpClass, each `Ran 0 tests`, because `verify_historical()` rejects `docs/HOSTED-CAO.md`. The frozen7146 preservation contract contains8912 files; excluding the separately governed orchestration-workflow migration, direct digest enumeration identifies exactly this one mismatch. The current document appends the authorized Phase A integration link/contract, but there is no corresponding versioned preservation successor path. An authorized content change is not yet an authorized exception in the executable preservation contract.

4. Runner manifest `executed_distinct_tests=63` counts recorded discovered IDs for these two failed setup classes. Only49 methods actually ran. It is fail-closed overall (`complete=false`) but must not be presented as63 executed or passed. The eventual complete receipt must reconcile actual log execution with the sidecar identities.

5. Actual discovery contains3995 distinct IDs across22 suites,55 Phase A additions and no historical removals. `release_population.required_ids()` only mandates the five historical remediation suites/63 IDs. It has no explicit required Phase A identity contract; current inclusion alone does not prove missing Phase A coverage fails closed. The release correction must pin and test that obligation.

6. Independent `git diff --name-only 02767e05 HEAD` enumeration finds eight evidence/documentation paths and no overlap with current458-file Python or2729-file release input maps. This supports publication equivalence for those maps. It does not establish a new receipt, proof contract or successful release.

7. Direct normal `verify_historical()` fails on the document. The same direct run under `python -O` refuses verifier import before acceptance, as designed. Probe commands/results are retained in `independent-verifier-probes.json`.

## Commands and evidence inspected

- `git rev-parse HEAD HEAD^{tree} origin/main`
- `git diff 97d06213 HEAD -- docs/HOSTED-CAO.md`
- `git diff --name-only 02767e05 HEAD`
- Direct SHA-256 enumeration against `skills/presumed-sources/release/historical-preservation.json` (only document mismatch beyond governed workflow).
- JSON structural comparison of historical HTTP proof to `source109.json`, then byte/JSON equality against `source971.json`.
- Independent arithmetic from source fixture using integer sums, without production charge helpers.
- `python [-O] -c "import runpy; x=runpy.run_path('skills/presumed-sources/verify_release.py'); print(x['verify_historical']())"`
- Actual `build4/release/phase-a-preflight-20261107/suite-18.log`, `suite-21.log`, and root runner preflight output; no duplicate preflight or full test execution by reviewer.
- Current release runner/population/verifier/receipt integrity source, workflow and original/corrected Phase A handoff/QA boundaries.

## Required next bounded infrastructure scope

Preserve historical proof, manifest and receipts unchanged. Introduce and independently verify additive source-bound successor proof/preservation contracts; select them fail-closed in actual workflow/verifier paths; pin mandatory Phase A IDs and correct setup-failure execution accounting; challenge stale/missing/tampered inputs and optimized Python before full dispatch. This is coordinated infrastructure work across proof selection, frozen preservation handling, coverage and receipt accounting, rather than a harmless replacement of expected hashes. Existing review is sufficient to stop this release path; it is not sufficient to approve an unimplemented successor. Whether this is handled in a separate bounded infrastructure assignment is the owner's/release agent's scope decision.

No accounting business logic was changed or reapproved. Original TrackedFR upload retesting, production deployment readiness and operational issues51–53 remain outside this preflight review. No genuine GitHub full-regression artifacts exist from this review; therefore the requested final artifact/receipt acceptance review remains outstanding.
