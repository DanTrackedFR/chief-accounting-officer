import sys,json,hashlib,subprocess
from pathlib import Path
from unittest.mock import patch
r=Path.cwd();sys.path[:0]=[str(r/'skills'),str(r/'skills/tests'),str(r)]
from production import PACKAGES
from borrowing_costs_cases import case
from implementation_scope import fingerprint_files
from phase_a_fingerprint import bind_phase_a
from source_fingerprint import bind_source_mode
c=case();files=fingerprint_files(c,r,PACKAGES)
h=lambda d:hashlib.sha256(d).hexdigest()
actual={str(p.relative_to(r)):h(p.read_bytes()) for p in files}
pin=h((r/'skills/phase_a_fingerprint.py').read_bytes())
name='skills/production.py'; historic='10a34f9fcbe28bb291373fe9c640470ee8bd1202b46590ec66a2a2105d28dfb4'
text=Path.read_text; binary=Path.read_bytes; targets={r/name,r/'interfaces/public_output.py'}
with patch.object(Path,'read_text',lambda p,*a,**kw:'inconsistent text' if p in targets else text(p,*a,**kw)):
 assert bind_phase_a(c,r,PACKAGES,files,actual,pin)[name]==historic
 assert bind_source_mode(c,r,PACKAGES,files,actual,h((r/'skills/source_fingerprint.py').read_bytes()))[name]!=historic
 for target in [r/'skills/phase_a_fingerprint.py',r/'skills/phase-a-compatibility/accepted-main-production.py.txt',r/'interfaces/public_output.py',r/name]:
  with patch.object(Path,'read_bytes',lambda p:binary(p)+(b'\0' if p==target else b'')):
   new={str(p.relative_to(r)):h(p.read_bytes()) for p in files}
   assert bind_phase_a(c,r,PACKAGES,files,new,pin)==new
   print('rejected authoritative mutation:',target.relative_to(r))
