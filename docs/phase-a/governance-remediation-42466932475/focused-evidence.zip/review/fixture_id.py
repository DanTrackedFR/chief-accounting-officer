from pathlib import Path
import importlib.util,subprocess as sp,sys
root=Path.cwd()
sys.path.insert(0,str(root))
spec=importlib.util.spec_from_file_location('reviewer_fixture',root/'tests/fixtures/phase_a_v1/runner.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
for _ in range(2):
 c=m.IndependentRunnerContract
 c.setUpClass()
 try:print(sp.check_output(['git','log','-1','--format=%H %T %at'],cwd=c.base,text=True).strip(),flush=True)
 finally:c.doClassCleanups()
