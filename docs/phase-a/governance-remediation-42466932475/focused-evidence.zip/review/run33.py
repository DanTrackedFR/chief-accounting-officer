import csv,json,sys,unittest
from pathlib import Path
r=Path.cwd()
rows=list(csv.DictReader(next(r.glob('docs/phase-a/failed-regression-*/affected-identities.tsv')).open(),delimiter='\t'))
wanted={x['identity'] for x in rows}
cases=[]
def leaf(s):
 for t in s:
  if isinstance(t,unittest.TestSuite):yield from leaf(t)
  else:yield t
for directory in ('skills/tests','tests'):
 sys.path.insert(0,str(r))
 loader=unittest.TestLoader()
 for t in leaf(loader.discover(directory,pattern='test_*.py')):
  if directory+'::'+t.id() in wanted: cases.append((directory+'::'+t.id(),t))
 if loader.errors: raise ValueError(loader.errors)
if len(cases)!=33: raise RuntimeError(cases)
ident={id(t):i for i,t in cases}; ledger={i:{'start':0,'success':0,'stop':0} for i,_ in cases}
class Observed(unittest.TextTestResult):
 def startTest(self,t):ledger[ident[id(t)]]['start']+=1;super().startTest(t)
 def addSuccess(self,t):ledger[ident[id(t)]]['success']+=1;super().addSuccess(t)
 def stopTest(self,t):ledger[ident[id(t)]]['stop']+=1;super().stopTest(t)
res=unittest.TextTestRunner(verbosity=2,resultclass=Observed).run(unittest.TestSuite(t for i,t in cases))
Path('../33-observations.json').write_text(json.dumps(ledger,indent=2,sort_keys=True)+'\n')
if not res.wasSuccessful() or any(row!={'start':1,'success':1,'stop':1} for row in ledger.values()):raise RuntimeError('Unsuccessful outcomes')
