from pathlib import Path
import importlib.util,tempfile,sys,json,hashlib
from unittest.mock import patch
r=Path.cwd();sys.path.insert(0,str(r))
sp=importlib.util.spec_from_file_location('independent_fixture',r/'tests/fixtures/phase_a_v1/runner.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
contracts=['phase-a-contracts/accepted-main-infrastructure-v1.json','release/phase-a-v1/proof-contract.json','release/phase-a-v1/governance-source-v2.json']
native=Path.read_bytes
with tempfile.TemporaryDirectory() as tmp:
 root=Path(tmp)/'isolated';root.mkdir()
 for name in contracts:
  target=m.SOURCE/name
  with patch.object(Path,'read_bytes',lambda p:native(p)+(b'\n' if p==target else b'')):
   try:m.bind_fixture_contracts(root)
   except ValueError as ex:
    assert str(ex)=='Fixture contract changed: '+name
    assert list(root.iterdir())==[]
    print('before first write',name)
   else:raise ValueError('mutated fixture input accepted')
 (root/'link').symlink_to(root.parent,target_is_directory=True)
 try:m.put(root,'link/probe','probe')
 except ValueError:assert not (root.parent/'probe').exists();print('redirect rejected')
 else:raise ValueError('outside fixture write')
 dep='build4/test_outcomes.py'
 with patch.object(Path,'read_bytes',lambda p:native(p)+(b'\n' if p==r/dep else b'')):
  try:m.copy_dependency(root,dep)
  except ValueError as ex:assert not (root/dep).exists();print('altered checkout module rejected',ex)
  else:raise ValueError('altered dependency accepted')
