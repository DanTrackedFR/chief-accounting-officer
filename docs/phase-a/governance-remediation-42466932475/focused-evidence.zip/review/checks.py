import subprocess as sp,sys,hashlib,json,os
from pathlib import Path
from unittest.mock import patch
r=Path.cwd();sys.path[:0]=[str(r/'skills/presumed-sources'),str(r)]
import proof_selection as p
from accepted_history import verify_accepted_main
from verify_release import verify_historical
print('main preservation',verify_accepted_main());print('earlier preservation',verify_historical())
print('selected',p.verify_output(p.selected_proof()))
def git(*args):return sp.check_output(['git',*args])
def h(data):return hashlib.sha256(data).hexdigest()
base='97d0621331c6ad2a66b12ed09c0ec40c05c626b9'
frozen='e025098beb849484e49d27f005adbcd30d508dc4'
d='skills/production.py';file=r/d
before=git('show',base+':'+d)
phase_helper=h((r/'skills/phase_a_fingerprint.py').read_bytes())
src_helper=h((r/'skills/source_fingerprint.py').read_bytes())
assert h(before)=='1283de1ef0a03808095284d734f574462567d624ffcf6aba7023a0e99ee6e16f'
start=b"from source_fingerprint import bind_source_mode\n    implementation = bind_source_mode(case, ROOT, PACKAGES, files, implementation, '"+src_helper.encode()+b"')"
end=b"from phase_a_fingerprint import bind_phase_a\n    implementation = bind_phase_a(case, ROOT, PACKAGES, files, implementation, '"+phase_helper.encode()+b"')"
assert before.count(start)==1 and before.replace(start,end)==file.read_bytes()
assert h(file.read_bytes())=='ede70f7c396fe9979b024fc1ae5f4ad06d59b8daee6e3c8c19d23596eafa9d26'
print('independent dispatcher replay',h(file.read_bytes()))
for fn in ('build4/release/presumed-sources-accepted-release.json','skills/presumed-sources/release/http-proof.json','diagnostics/profile12/runner-recovery/independent-qa/test_runner_contract.py'):
 assert git('show',base+':'+fn)==(r/fn).read_bytes()
for fn in ('skills/presumed-sources/release/phase-a-v1/proof-contract.json','skills/presumed-sources/release/phase-a-v1/http-proof.json'):
 assert git('show',frozen+':'+fn)==(r/fn).read_bytes()
native=Path.read_bytes
for file in (r/p.SUCCESSOR,r/p.CONTRACT,r/'skills/tests/test_independent_ip_main_reconciliation.py'):
 with patch.object(Path,'read_bytes',lambda self, file=file:native(self)+(b'\n' if self==file else b'')):
  try:p.selected_proof()
  except ValueError as ex:print('rejected',file.name,str(ex))
  else:raise ValueError('failed to reject '+str(file))
for flags in (['-O'],['-OO']):
 result=sp.run([sys.executable,*flags,'-m','build4.verify_release'],capture_output=True,text=True)
 assert result.returncode and 'Optimized Python is not supported' in result.stderr
 print('optimized refusal',flags,result.returncode)
