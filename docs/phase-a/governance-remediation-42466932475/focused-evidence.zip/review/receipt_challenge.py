from pathlib import Path
import importlib.util,copy,subprocess as sp,sys,json,os
r=Path.cwd();sys.path.insert(0,str(r));spec=importlib.util.spec_from_file_location('receipt_review_fixture',r/'tests/fixtures/phase_a_v1/runner.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);c=m.IndependentRunnerContract
c.setUpClass()
try:
 root=c.base
 seed=json.loads((root/'build4/release/qa-seed/release-regression.json').read_bytes())
 def check(v,reason=None):
  p=sp.run([sys.executable,'-c',"import sys,json;sys.path.insert(0,'skills/presumed-sources');from verify_release import validate_population;validate_population(json.load(sys.stdin))"],cwd=root,env=c.env,input=json.dumps(v),text=True,capture_output=True)
  if reason is None:
   assert p.returncode==0,p.stderr
  else:
   assert p.returncode and reason in p.stderr,p.stderr
 print('genuine synthetic execution',seed['source_commit'],seed['passed_distinct_tests'])
 check(seed)
 v=copy.deepcopy(seed);v['logs'][0]['command'][0]='/custom/installation/python3.12';check(v)
 print('accepted relocated governed interpreter')
 v=copy.deepcopy(seed);v['logs'][0]['command'][0]='/custom/installation/untrusted';check(v,'Unexpected test interpreter')
 print('rejected unrelated interpreter executable')
 v=copy.deepcopy(seed);v['logs'][0]['command'][1]='other.py';check(v,'command population differs')
 v=copy.deepcopy(seed);v['outcome_schema_version']=0;check(v,'Missing actual execution receipt semantics')
 v=copy.deepcopy(seed);del v['outcome_schema_version'];check(v,'Missing actual execution receipt semantics')
 v=copy.deepcopy(seed);v['passed_distinct_tests']=v['scheduled_distinct_tests']-1;check(v,'Aggregate execution count differs')
 print('rejected command, missing schema, wrong schema and altered passed count')
 assert list(root.rglob('*.pyc'))==[]
 verify=[sys.executable,'-m','build4.verify_release','--pointer','build4/release/qa-pointer.json']
 p=sp.run(verify,cwd=root,env=c.env,text=True,capture_output=True);assert p.returncode==0,p.stderr
 target=root/'build4/release/qa-seed/start-input-hashes.json';target.write_bytes(target.read_bytes()+b'\n')
 p=sp.run(verify,cwd=root,env=c.env,text=True,capture_output=True)
 assert p.returncode and 'Evidence inventory artifact changed' in p.stderr,p.stderr
 print('sealed source-input sidecar byte mutation refused after full verifier positive')
finally:c.doClassCleanups()
