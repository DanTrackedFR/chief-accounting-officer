import csv,sys,unittest,os,pathlib
root=pathlib.Path.cwd()
sys.path[:0]=[str(root/'tests'),str(root/'skills/tests'),str(root)]
import test_presumed_runner_recovery as runner
sys.modules['independent_runner_recovery_qa']=runner._module
rows=list(csv.DictReader(next(root.glob('docs/phase-a/failed-regression*/affected-identities.tsv')).open(),delimiter='\t'))
tests=[r['identity'].split('::')[1] for r in rows if not sys.argv[1:] or any(x in r['identity'] for x in sys.argv[1:])]
suite=unittest.defaultTestLoader.loadTestsFromNames(tests)
sys.exit(not unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful())
