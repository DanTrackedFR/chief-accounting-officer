"""Validate the bounded production receipt against its inputs, sides and failed-run population."""
import csv, gzip, hashlib, json, subprocess, sys
from pathlib import Path
root=Path.cwd()
sys.path[:0]=[str(root),str(root/'skills/presumed-sources')]
from build4.run_release import source_hashes
from build4.test_outcomes import aggregate, validate_outcomes
from release_population import release_input_hashes, verify_source_binding, gate_plan, required_ids, phase_a_required_ids
from proof_selection import selected_proof, CONTRACT_SHA256
from accepted_history import verify_accepted_main
from verify_release import verify_historical
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path): return json.loads(path.read_bytes())
attempt=sys.argv[1]
folder=root/'build4/release'/attempt
manifest=read(folder/'bounded-preflight.json')
inventory=read(folder/'discovery.json')
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert manifest['source_commit']==inventory['source_commit']==commit
assert manifest['full_accounting_regression_executed'] is False and manifest['release_accepted'] is False
assert manifest['complete'] and manifest['source_unchanged'] and manifest['outcome_schema_version']==1
assert not (folder/'release-regression.json').exists() and not (folder/'execution.json').exists()
assert manifest['gate_plan']==gate_plan(attempt,commit)
rows=inventory['suite_results']
assert len(rows)==23
ids=[i for row in rows for i in row['distinct_ids']]
ledger=next(root.glob('docs/phase-a/failed-regression*/identity-ledger.tsv.gz'))
historical=list(csv.DictReader(gzip.decompress(ledger.read_bytes()).decode().splitlines(),delimiter='\t'))
extra='tests::test_presumed_population_dispatch.ProductionPopulationDispatch.test_missing_outcome_dependency_refused_before_execution'
assert len(set(ids))==len(ids)==4012
assert set(ids)=={r['identity'] for r in historical}|{extra}
for idx,row in enumerate(rows):
 expected={r['identity'] for r in historical if int(r['slot'])==idx}
 if idx==3:expected.add(extra)
 assert set(row['distinct_ids'])==expected
must={i for r in required_ids() for i in r['distinct_ids']}|set(phase_a_required_ids())
assert len(must)==118 and must<=set(ids)
assert len(rows[22]['distinct_ids'])==16
actual=manifest['suite_results']
assert len(actual)==6 and manifest['outcomes']==aggregate(actual)
for idx,row in enumerate(actual,17):
 assert validate_outcomes(row)==set(rows[idx]['distinct_ids'])
 assert {k:v for k,v in row.items() if k!='exit_code'}==read(folder/f'suite-{idx}.json')
assert set(manifest['outcomes']['passed_ids'])==set(manifest['outcomes']['scheduled_ids'])
counts={k:manifest[k+'_distinct_tests'] for k in ('discovered','scheduled','executed','passed','failed','errored','skipped','unexecuted')}
assert list(counts.values())==[4012,79,79,79,0,0,0,0]
for row in manifest['logs']:
 assert row['exit_code']==0 and row['sha256']==sha(root/row['path'])
assert len(manifest['logs'])==11
assert (folder/'proof-109.log').read_bytes()==(folder/'proof-971.log').read_bytes()==selected_proof().read_bytes()
assert manifest['proof_contract_sha256']==CONTRACT_SHA256
sources,inputs=source_hashes(),release_input_hashes()
assert sources==manifest['tested_python_sha256']==read(folder/'start-source-hashes.json')
assert inputs==manifest['tested_execution_inputs_sha256']==read(folder/'start-input-hashes.json')
assert verify_source_binding(commit,sources,inputs)
assert verify_historical()==8912
summary=dict(candidate=commit,tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),
 attempt=attempt,counts=counts,suites=len(rows),required=len(must),infrastructure_ids=16,additional_governance_id=extra,
 bounded_suites=[{'suite':r['suite'],'pattern':r['pattern'],'observed_passes':len(r['passed_ids'])} for r in actual],
 source_map_count=len(sources),source_map_sha256=sha(folder/'start-source-hashes.json'),input_map_count=len(inputs),
 input_map_sha256=sha(folder/'start-input-hashes.json'),proof_sha256=sha(selected_proof()),proof_version=manifest['proof_version'],
 source_contract_sha256=CONTRACT_SHA256,accepted_main=verify_accepted_main(),historical_files=8912,
 full_accounting_regression_executed=False,release_accepted=False)
print(json.dumps(summary,indent=2,sort_keys=True))
