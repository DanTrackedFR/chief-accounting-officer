from pathlib import Path
import os,subprocess,json,hashlib,concurrent.futures
from orchestration.history_references import reference_path
out=Path('../infra-evidence/compatibility');out.mkdir(exist_ok=True)
items=[('prepared','hosted_cao.tests.prove_prepared_http',[41,1481],Path('skills/prepared-accounting/release/http-proof.json')),
       ('hosted','hosted_cao.tests.prove_http',[19,941],reference_path('hosted_cao/release/http-proof.json')),
       ('build4','build4.prove_integrated',[283,1709],reference_path('build4/release/integrated-proof.json')),
       ('memory','build4.prove_memory',[283,1709],reference_path('build4/release/memory-proof.json')),
       ('build3','intelligence.tests.prove_integrated',[19,941],reference_path('intelligence/release/integrated-proof.json')),
       ('local','local_cao.tests.prove_cli',[19,941],reference_path('local_cao/examples/cli-proof.json'))]
def run(item):
 name,module,seeds,expected=item;rows=[]
 for seed in seeds:
  cmd=['python','-m',module];p=subprocess.run(cmd,env={**os.environ,'PYTHONHASHSEED':str(seed)},capture_output=True,timeout=180)
  (out/(name+'-'+str(seed)+'.json')).write_bytes(p.stdout);(out/(name+'-'+str(seed)+'.stderr')).write_bytes(p.stderr)
  rows.append(dict(command=cmd,seed=seed,exit_code=p.returncode,sha256=hashlib.sha256(p.stdout).hexdigest(),expected=str(expected),byte_equal=p.stdout==expected.read_bytes()))
 return dict(name=name,results=rows,passed=all(r['exit_code']==0 and r['byte_equal'] for r in rows))
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(run,items))
(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps([{r['name']:r['passed']} for r in rows]));raise SystemExit(0 if all(r['passed'] for r in rows) else 1)
