import sys,json
sys.path.insert(0,'.')
from hosted_cao.tests.test_presumed_engineering_qa import IndependentPresumedEngineeringQA
f=IndependentPresumedEngineeringQA('test_real_http_27_machinery_rows_and_10_invoices');f.setUp()
try:
 print(json.dumps({p:f.complete(p,p)[1]['accounting']['public_result'] for p in ('fixed-assets','accounts-payable')},sort_keys=True,indent=2))
finally:f.doCleanups()
