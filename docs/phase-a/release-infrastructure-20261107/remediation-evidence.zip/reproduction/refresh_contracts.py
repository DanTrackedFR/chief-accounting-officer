from pathlib import Path
import json,hashlib,re,sys
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=Path('skills/presumed-sources/phase-a-contracts/accepted-main-infrastructure-v1.json');d=json.loads(p.read_text())
for n,row in d['source_migrations'].items():row['successor_sha256']=h(Path(n))
p.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
f=Path('skills/presumed-sources/accepted_history.py');f.write_text(re.sub("CONTRACT_SHA256='[0-9a-f]+'", "CONTRACT_SHA256='"+h(p)+"'",f.read_text()))
sys.path[:0]=[str(Path.cwd()),'skills/presumed-sources']
from build4.run_release import input_hashes
p=Path('skills/presumed-sources/release/phase-a-v1/proof-contract.json');d=json.loads(p.read_text());d['proof_inputs_sha256']={n:v for n,v in input_hashes().items() if not n.endswith('.py') and n!='.github/workflows/cao-presumed-sources.yml'};p.write_text(json.dumps(d,sort_keys=True,indent=2)+'\n')
f=Path('skills/presumed-sources/proof_selection.py');f.write_text(re.sub("CONTRACT_SHA256 = '[0-9a-f]+'", "CONTRACT_SHA256 = '"+h(p)+"'",f.read_text()))
