import json,hashlib,subprocess
from pathlib import Path
r=Path.cwd(); a=json.loads((r/'skills/presumed-sources/release/http-proof.json').read_text());b=json.loads((r/'../infra-evidence/proof109.json').read_text())
def diff(a,b,p=''):
 if type(a)!=type(b):return [(p,a,b)]
 if isinstance(a,dict):return sum((diff(a.get(k),b.get(k),p+'/'+k) for k in sorted(set(a)|set(b))),[])
 if isinstance(a,list):return sum((diff(x,y,p+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))),[]) if len(a)==len(b) else [(p,a,b)]
 return [] if a==b else [(p,a,b)]
x=diff(a,b);print(json.dumps(x,indent=2));print('seeds equal',Path('../infra-evidence/proof109.json').read_bytes()==Path('../infra-evidence/proof971.json').read_bytes())
Path('../infra-evidence/proof-differences.json').write_text(json.dumps(x,indent=2)+'\n')
