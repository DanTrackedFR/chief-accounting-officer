import json,subprocess,sys,os,hashlib,contextlib
from pathlib import Path
B=Path(__file__).resolve().parent;R=B/'candidate';rows=[];py=sys.executable

def run(label,args,cwd=R,env=None,good=True):
 p=subprocess.run(args,cwd=cwd,env={**os.environ,**(env or {})},text=True,capture_output=True,timeout=300)
 d=dict(label=label,command=args,cwd=str(cwd),environment=env or {},exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr);rows.append(d)
 (B/(label+'.json')).write_text(json.dumps(d,indent=2)+'\n');assert (p.returncode==0)==good,(label,p.stdout,p.stderr);return p
run('fixed-authored-infrastructure',[py,'-m','unittest','discover','-s','tests/phase_a_release_infra','-v'])
code="""import sys,copy;sys.path[:0]=['tests/phase_a_release_infra','skills/presumed-sources'];from test_infrastructure import ReceiptAdversarial
v,d=ReceiptAdversarial().model();v.validate_population(d)
for x in ('missing',-999,True,'3995'):
 b=copy.deepcopy(d)
 if x=='missing':b.pop('discovered_distinct_tests')
 else:b['discovered_distinct_tests']=x
 try:v.validate_population(b)
 except ValueError as e:print(x, 'REJECTED',str(e))
 else:raise AssertionError('tampered discovery accepted')
"""
run('fixed-discovery-count-negative',[py,'-c',code])
# New file additions must be rejected, even where previously explicit keys match.
for label,name,data in [('fixed-proof-added-source','orchestration/reviewer_unexpected.py',b'# added source\n'),('fixed-proof-added-input','interfaces/reviewer_unexpected.json',b'{}\n')]:
 p=R/name;assert not p.exists();p.write_bytes(data)
 try:run(label,[py,'skills/presumed-sources/proof_selection.py','--version','phase-a-v1','--output','skills/presumed-sources/release/phase-a-v1/http-proof.json'],good=False)
 finally:p.unlink()
run('fixed-historical-positive',[py,'-c',"import runpy; print(runpy.run_path('skills/presumed-sources/verify_release.py')['verify_historical']())"])
# Old issued receipt must now fail after source changed.
run('fixed-rejects-old-source-focused-receipt',[py,'skills/presumed-sources/verify_release.py','--focused','diagnostics/profile12/remediation/independent-reviewer-control-pointer.json'],good=False)
p=run('fixed-new-focused-issue',[py,'diagnostics/profile12/remediation/issue_focused_receipt.py','independent-reviewer-final'])
run('fixed-new-focused-positive',[py,'skills/presumed-sources/verify_release.py','--focused',p.stdout.strip().splitlines()[-1]])
history=Path('/workspace/scratch/0ec4b9136cd2/historical-proof')
run('historical-original-identity',['git','rev-parse','HEAD'],cwd=history)
a=run('historical-original-seed109',[py,'-m','hosted_cao.tests.prove_presumed_http'],cwd=history,env={'PYTHONHASHSEED':'109'})
b=run('historical-original-seed971',[py,'-m','hosted_cao.tests.prove_presumed_http'],cwd=history,env={'PYTHONHASHSEED':'971'})
assert a.stdout==b.stdout
assert hashlib.sha256(a.stdout.encode()).hexdigest()=='be06ab1a1ee247bc24159f7ad605eb30c1dc70fccb13c864b50a9da25e88bcb7'
(B/'recheck-summary.json').write_text(json.dumps(dict(reviewed_sha='1114eb9f4b78913be8f2695bc38c8413843ca49c',records=rows),indent=2)+'\n')
print('Final correction controls passed',len(rows))
