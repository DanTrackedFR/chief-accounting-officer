import copy,contextlib,hashlib,json,os,subprocess,sys,uuid
from pathlib import Path
B=Path(__file__).resolve().parent;R=B/'candidate';sys.path[:0]=[str(R),str(R/'skills/presumed-sources'),str(R/'tests/phase_a_release_infra')];os.chdir(R)
from test_infrastructure import ReceiptAdversarial,verifier
v,d=ReceiptAdversarial().model();v.validate_population(d);rows=[]
for key in ('failed','errored','skipped','unexecuted'):
 for value in (False,0.0,'0',None):
  bad=copy.deepcopy(d);bad[key+'_distinct_tests']=value
  try:v.validate_population(bad)
  except ValueError as e:rows.append(dict(control='aggregate_counter_type',field=key,value=value,result='REJECTED',error=str(e)))
  else:raise AssertionError(('invalid aggregate type accepted',key,value))
# Minimal negative receipt must reject at strict completion guard before inventory.
p=R/'build4/release'/('independent-type-negative-'+uuid.uuid4().hex);p.mkdir();manifest=p/'manifest.json';pointer=p/'pointer.json'
try:
 for field in ('complete','source_unchanged'):
  for value in (1,'true',[],{},None):
   data=dict(complete=True,source_unchanged=True);data[field]=value;manifest.write_text(json.dumps(data));pointer.write_text(json.dumps(dict(manifest=str(manifest.relative_to(R)),sha256=hashlib.sha256(manifest.read_bytes()).hexdigest())))
   try:v.verify(str(pointer.relative_to(R)))
   except ValueError as e:
    assert str(e)=='Incomplete Presumed-source release',str(e)
    rows.append(dict(control='completion_type',field=field,value=value,result='REJECTED_AT_COMPLETION_GUARD',error=str(e)))
   else:raise AssertionError(('truthy completion accepted',field,value))
finally:
 manifest.unlink();pointer.unlink();p.rmdir()
env={k:v for k,v in os.environ.items() if k!='PYTHONPATH'}
for label,args in [('final-permanent16',[sys.executable,'-m','unittest','discover','-s','tests/phase_a_release_infra','-v']),('final-historical-positive',[sys.executable,'-c',"import runpy;print(runpy.run_path('skills/presumed-sources/verify_release.py')['verify_historical']())"]),('final-standalone-selector-positive',[sys.executable,'skills/presumed-sources/proof_selection.py','--version','phase-a-v1','--output','skills/presumed-sources/release/phase-a-v1/http-proof.json'])]:
 q=subprocess.run(args,cwd=R,env=env,capture_output=True,text=True,timeout=300);assert q.returncode==0,(label,q.stderr);rows.append(dict(control=label,command=args,environment_delta={'PYTHONPATH':'REMOVED'},exit_code=q.returncode,stdout=q.stdout,stderr=q.stderr))
(B/'final-receipt-type-controls.json').write_text(json.dumps(dict(reviewed_commit='529e768004e199c3a4d553060a7c0521fa50d4b3',reviewed_tree='d70734be13e7b8e4808d40dc20f3541735ca31b9',conclusion='PASS',records=rows),indent=2)+'\n')
print('Final receipt type controls PASS',len(rows),'records;16 permanent methods;historical positive;standalone CLI positive')
