import json,subprocess,os,sys,hashlib
from pathlib import Path
B=Path(__file__).resolve().parent;R=B/'candidate';env={k:v for k,v in os.environ.items() if k!='PYTHONPATH'};rows=[]
def run(label,args,good=True,extra=None):
 p=subprocess.run(args,cwd=R,env={**env,**(extra or {})},capture_output=True,text=True,timeout=300)
 d=dict(label=label,command=args,environment_delta=dict(PYTHONPATH='REMOVED',**(extra or {})),exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr);rows.append(d)
 assert (p.returncode==0)==good,(label,p.stderr);return p
run('permanent16-clean-environment',[sys.executable,'-m','unittest','discover','-s','tests/phase_a_release_infra','-v'])
proofs=[]
for seed in ('109','971'):
 p=run('actual-proof-'+seed,[sys.executable,'-m','hosted_cao.tests.prove_presumed_http'],extra={'PYTHONHASHSEED':seed});path=B/('qa-f02-proof-'+seed+'.json');path.write_text(p.stdout);proofs.append(p.stdout)
 for flag in (None,'-O','-OO'):
  args=[sys.executable]+([flag] if flag else [])+['skills/presumed-sources/proof_selection.py','--version','phase-a-v1','--output',str(path)]
  run('standalone-selector-'+seed+'-'+(flag or 'normal'),args)
assert proofs[0]==proofs[1] and hashlib.sha256(proofs[0].encode()).hexdigest()=='b973931977a198aced1c01ce2d3eb9013892a7f9c87114049e46714a488eef5d'
run('standalone-wrong-version',[sys.executable,'skills/presumed-sources/proof_selection.py','--version','historical','--output',str(B/'qa-f02-proof-109.json')],False)
for flag in ('-O','-OO'):
 run('mandatory-verifier-'+flag,[sys.executable,flag,'-c',"import runpy;runpy.run_path('skills/presumed-sources/verify_release.py')['verify_historical']()"],False)
(B/'QA-F02-resolution.json').write_text(json.dumps(dict(reviewed_commit='b1fe2bbaedb09fd3a693db534f4ffe2e506ad65f',reviewed_tree='2459707c2ce79af08fbb07039199676f9718e768',scope='bounded independent CLI fix recheck only',conclusion='PASS',records=rows),indent=2)+'\n')
print('QA-F02 resolved:',len(rows),'clean-environment subprocess controls pass;16 permanent methods passed')
