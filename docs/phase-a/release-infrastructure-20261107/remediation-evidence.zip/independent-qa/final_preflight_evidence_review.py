"""Read-only independent evidence inspection; never imports or executes test code."""
import hashlib,json,re,subprocess
from pathlib import Path
B=Path(__file__).resolve().parent;R=B.parent/'cao';O=R/'build4/release/phase-a-infra-bounded-final-20261107'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads((O/'bounded-preflight.json').read_bytes());inv=json.loads((O/'discovery.json').read_bytes())
assert d['source_commit']=='7e14f99008cd4f30ec0200e17441264b5df2a4fc'
assert d['attempt']==O.name and d['complete'] is True and d['source_unchanged'] is True
assert d['scope']=='bounded-remediation-preflight' and d['release_accepted'] is False and d['full_accounting_regression_executed'] is False
for key in ('failed','errored','skipped','unexecuted'):assert d[key+'_distinct_tests']==0 and not d['outcomes'][key+'_ids']
assert inv['attempt']==d['attempt'] and inv['source_commit']==d['source_commit'] and inv['discovered_distinct_tests']==d['discovered_distinct_tests']==4011
all_discovered=[i for r in inv['suite_results'] for i in r['distinct_ids']];assert len(inv['suite_results'])==23 and len(all_discovered)==len(set(all_discovered))==4011
scheduled=[];executed=[];passed=[];suite_summary=[]
for row,slot in zip(d['suite_results'],d['gate_plan'][17:]):
 assert row['suite']==slot['suite'] and row['pattern']==slot['pattern']
 sidecar=O/('suite-'+str(slot['index'])+'.json');assert json.loads(sidecar.read_bytes())=={k:v for k,v in row.items() if k!='exit_code'}
 expected=inv['suite_results'][slot['index']]['distinct_ids']
 assert row['distinct_ids']==row['discovered_ids']==row['scheduled_ids']==row['executed_ids']==row['passed_ids']==expected
 assert row['passed'] is True and row['exit_code']==0 and row['tests']==len(expected)
 assert row['errors']==row['failures']==row['skipped']==0 and not row['suite_errors']
 for k in ('failed_ids','errored_ids','skipped_ids','unexecuted_ids'):assert row[k]==[]
 text=(O/('suite-'+str(slot['index'])+'.log')).read_text();runs=re.findall(r'^Ran (\d+) tests? in ',text,re.M);assert runs==[str(len(expected))],(slot['index'],runs)
 assert re.search(r'^OK$',text,re.M)
 scheduled+=row['scheduled_ids'];executed+=row['executed_ids'];passed+=row['passed_ids']
 suite_summary.append(dict(index=slot['index'],suite=row['suite'],pattern=row['pattern'],executed=len(expected),sidecar_sha256=h(sidecar),log_sha256=h(O/('suite-'+str(slot['index'])+'.log'))))
assert len(d['suite_results'])==6
assert len(scheduled)==len(set(scheduled))==len(executed)==len(set(executed))==len(passed)==len(set(passed))==79
for k,ids in [('scheduled',scheduled),('executed',executed),('passed',passed)]:assert sorted(ids)==d['outcomes'][k+'_ids'] and d[k+'_distinct_tests']==len(ids)
assert len(d['logs'])==11 and all(x['exit_code']==0 for x in d['logs'])
for log in d['logs']:assert h(R/log['path'])==log['sha256']
for name,key in [('start-source-hashes.json','tested_python_sha256'),('start-input-hashes.json','tested_execution_inputs_sha256')]:
 values=json.loads((O/name).read_bytes());assert values==d[key]
 for n,expected in values.items():assert h(R/n)==expected,n
actual_py={str(p.relative_to(R)):h(p) for p in R.rglob('*.py') if '.git' not in p.parts};assert actual_py==d['tested_python_sha256']
# Read Git objects/metadata only; no release verifier or test entrypoint called.
treeout=subprocess.check_output(['git','ls-tree','-r',d['source_commit']],cwd=R,text=True)
tree={line.split('\t',1)[1]:line.split()[2] for line in treeout.splitlines()}
for n,expected in {**d['tested_python_sha256'],**d['tested_execution_inputs_sha256']}.items():
 data=(R/n).read_bytes();blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();assert tree[n]==blob,n
proof=(R/'skills/presumed-sources/release/phase-a-v1/http-proof.json').read_bytes();assert (O/'proof-109.log').read_bytes()==(O/'proof-971.log').read_bytes()==proof
assert hashlib.sha256(proof).hexdigest()==d['proof_sha256']=='b973931977a198aced1c01ce2d3eb9013892a7f9c87114049e46714a488eef5d'
assert d['proof_version']=='phase-a-v1'
assert h(R/'skills/presumed-sources/release/phase-a-v1/proof-contract.json')==d['proof_contract_sha256']=='0cfd93e3d75f3bd9d781422bbbf97129607fe07253a09dba6d80f911de673694'
for seed in ('109','971'):
 x=json.loads((O/('proof-selection-'+seed+'.log')).read_text());assert x['proof_version']=='phase-a-v1' and x['sha256']==d['proof_sha256']
assert (O/'historical-preservation.log').read_text().strip()=='8912'
phase=json.loads((R/'skills/presumed-sources/phase-a-contracts/required-tests-v1.json').read_text())['required_ids']
historical=[i for r in json.loads((R/'skills/presumed-sources/required-remediation-tests.json').read_text())['suites'] for i in r['distinct_ids']]
assert len(phase)==55 and len(historical)==63 and set(phase+historical)<=set(all_discovered) and set(historical)<=set(executed)
files={str(p.relative_to(O)):h(p) for p in sorted(O.rglob('*')) if p.is_file()}
summary=dict(review='independent read-only actual production bounded-preflight evidence inspection; no tests rerun',source_commit=d['source_commit'],attempt=d['attempt'],complete=True,source_unchanged=True,discovered_distinct=4011,mandatory_phase_a_discovered=55,mandatory_historical_executed=63,scheduled=79,executed=79,passed=79,failed=0,errored=0,skipped=0,unexecuted=0,suites=suite_summary,command_logs=11,all_command_exit_codes=0,source_map_files=len(d['tested_python_sha256']),execution_input_map_files=len(d['tested_execution_inputs_sha256']),proof_version=d['proof_version'],proof_sha256=d['proof_sha256'],proof_contract_sha256=d['proof_contract_sha256'],historical_verifier_output=8912,release_accepted=False,full_accounting_regression_executed=False,manifest_sha256=h(O/'bounded-preflight.json'),artifact_files=files)
(B/'final-production-preflight-evidence-review.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('artifact_files','suites')},sort_keys=True,indent=2))
