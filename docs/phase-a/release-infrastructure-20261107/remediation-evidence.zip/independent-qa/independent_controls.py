"""Fresh reviewer controls; mutations confined to disposable candidate."""
import contextlib,hashlib,json,os,subprocess,sys,time
from pathlib import Path
BASE=Path(__file__).resolve().parent
ROOT=BASE/'candidate'
records=[]

def run(label,args,cwd=ROOT,env=None,expect=0):
 started=time.monotonic();p=subprocess.run(args,cwd=cwd,env={**os.environ,**(env or {})},capture_output=True,text=True,timeout=300)
 row=dict(label=label,command=args,cwd=str(cwd),environment=env or {},returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,seconds=round(time.monotonic()-started,3))
 records.append(row);(BASE/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 if expect is not None:assert (p.returncode==0)==(expect==0),(label,p.stdout,p.stderr)
 return p

@contextlib.contextmanager
def mutate(name,data=None):
 p=ROOT/name;old=p.read_bytes()
 try:
  if data is None:p.unlink()
  else:p.write_bytes(data)
  yield
 finally:p.write_bytes(old)

py=sys.executable
run('proof-seed109',[py,'-m','hosted_cao.tests.prove_presumed_http'],env={'PYTHONHASHSEED':'109'})
run('proof-seed971',[py,'-m','hosted_cao.tests.prove_presumed_http'],env={'PYTHONHASHSEED':'971'})
a=json.loads((BASE/'proof-seed109.json').read_text())['stdout'];b=json.loads((BASE/'proof-seed971.json').read_text())['stdout'];assert a==b
proof='skills/presumed-sources/release/phase-a-v1/http-proof.json';assert a.encode()==(ROOT/proof).read_bytes()
run('proof-selector',[py,'skills/presumed-sources/proof_selection.py','--version','phase-a-v1','--output',proof])
run('proof-wrong-version',[py,'skills/presumed-sources/proof_selection.py','--version','historical','--output',proof],expect=1)
for label,name,data in [
 ('proof-missing',proof,None),('proof-tamper',proof,b'{}\n'),
 ('proof-stale',proof,(ROOT/'skills/presumed-sources/release/http-proof.json').read_bytes()),
 ('proof-source-mismatch','orchestration/runtime.py',(ROOT/'orchestration/runtime.py').read_bytes()+b'\n# reviewer mutation\n'),
 ('proof-input-mismatch','interfaces/CAO-CONTEXT-EVIDENCE-DOCUMENT-CONTRACT.md',(ROOT/'interfaces/CAO-CONTEXT-EVIDENCE-DOCUMENT-CONTRACT.md').read_bytes()+b'\n# reviewer mutation\n')]:
 with mutate(name,data):run(label,[py,'skills/presumed-sources/proof_selection.py','--version','phase-a-v1','--output',proof],expect=1)
cmd=[py,'-c',"import runpy;print(runpy.run_path('skills/presumed-sources/verify_release.py')['verify_historical']())"]
run('historical-positive',cmd)
for label,name,data in [
 ('migration-missing','skills/presumed-sources/phase-a-contracts/hosted-doc-migration-v1.json',None),
 ('migration-tamper','skills/presumed-sources/phase-a-contracts/hosted-doc-migration-v1.json',b'{}\n'),
 ('doc-future-change','docs/HOSTED-CAO.md',(ROOT/'docs/HOSTED-CAO.md').read_bytes()+b'\n# reviewer unauthorized\n'),
 ('old-doc-tamper','skills/presumed-sources/phase-a-contracts/HOSTED-CAO.original.md',b'wrong original'),
 ('unrelated-history-mutation','skills/presumed-sources/release/http-proof.json',b'{}\n'),
 ('previous-workflow-migration-mutation','.github/workflows/cao-orchestration.yml',(ROOT/'.github/workflows/cao-orchestration.yml').read_bytes()+b'\n# reviewer unauthorized\n')]:
 with mutate(name,data):run(label,cmd,expect=1)
for flag in ('-O','-OO'):run('optimized-'+flag[1:],[py,flag,*cmd[1:]],expect=1)
# Real19 receipt, real callback sidecar, independent mutations.
p=run('issue-focused-positive',[py,'diagnostics/profile12/remediation/issue_focused_receipt.py','independent-reviewer-control'])
pointer=p.stdout.strip().splitlines()[-1]
run('focused-positive',[py,'skills/presumed-sources/verify_release.py','--focused',pointer])
pd=json.loads((ROOT/pointer).read_text());manifest=ROOT/pd['manifest'];md=json.loads(manifest.read_text());attempt=manifest.parent
for label,name,data in [('receipt-missing-sidecar',str((attempt/'suite-0.json').relative_to(ROOT)),None),('receipt-truncated-sidecar',str((attempt/'suite-0.json').relative_to(ROOT)),b'{'),('receipt-log-tamper',md['logs'][0]['path'],b'{}'),('receipt-source-mismatch','orchestration/runtime.py',(ROOT/'orchestration/runtime.py').read_bytes()+b'\n# changed after execution\n')]:
 with mutate(name,data):run(label,[py,'skills/presumed-sources/verify_release.py','--focused',pointer],expect=1)
# Independent semantic negatives with no receipt publication.
code="""import sys,copy;sys.path[:0]=['tests/phase_a_release_infra','skills/presumed-sources'];from test_infrastructure import ReceiptAdversarial
v,d=ReceiptAdversarial().model();v.validate_population(d);print('MISSING discovered_distinct_tests ACCEPTED')
d['discovered_distinct_tests']=-999;v.validate_population(d);print('TAMPERED discovered_distinct_tests ACCEPTED')
"""
run('finding-discovered-count-unchecked',[py,'-c',code])
# Independently retained inventory of source proof and arithmetic expectations.
d=json.loads((ROOT/proof).read_text());amounts={r['package']:{i['label']:i['amount'] for i in r['calculations']} for r in d['executions']}
assert sum(10000+i*1000 for i in range(1,28))==648000
assert sum(100+i*10 for i in range(1,11))==1550
assert amounts['fixed-assets']['closing cost']=='648000' and amounts['fixed-assets']['depreciation']=='64800.00' and amounts['accounts-payable']['invoices']=='1550'
(BASE/'independent-controls-summary.json').write_text(json.dumps(dict(reviewed_sha='bf5a5a626f6a08458ba59c8b0313b4745c45d07d',controls=len(records),records=records,proof_sha256=hashlib.sha256(a.encode()).hexdigest(),independent_amounts=amounts),indent=2)+'\n')
print('controls',len(records),'complete')
