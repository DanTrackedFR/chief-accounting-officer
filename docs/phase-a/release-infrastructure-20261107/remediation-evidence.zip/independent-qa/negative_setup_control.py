import json,os,subprocess,sys,time
from pathlib import Path
B=Path(__file__).resolve().parent;R=B/'negative-candidate';source=B/'candidate'
subprocess.run(['git','clone','--shared','--no-checkout',str(source),str(R)],check=True,capture_output=True)
subprocess.run(['git','checkout','--detach','bf5a5a626f6a08458ba59c8b0313b4745c45d07d'],cwd=R,check=True,capture_output=True)
p=R/'docs/HOSTED-CAO.md';p.write_bytes(p.read_bytes()+b'\n# independent unauthorized setup reproduction\n')
subprocess.run(['git','add','docs/HOSTED-CAO.md'],cwd=R,check=True)
subprocess.run(['git','-c','user.name=Independent QA','-c','user.email=qa@example.invalid','commit','-m','Disposable negative setup fixture; never publish'],cwd=R,check=True,capture_output=True)
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
sys.path[:0]=[str(R),str(R/'skills/presumed-sources')]
from release_population import gate_plan
from build4.test_outcomes import aggregate,validate_outcomes
attempt='independent-real-setup-failure';rows=[];logs=[]
for slot in gate_plan(attempt,sha)[17:22]:
 env={**os.environ,**slot['environment']};p=subprocess.run([sys.executable,*slot['command'][1:]],cwd=R,env=env,capture_output=True,text=True,timeout=300)
 row=json.loads((R/f"build4/release/{attempt}/suite-{slot['index']}.json").read_text());row['exit_code']=p.returncode;rows.append(row)
 logs.append(dict(command=[sys.executable,*slot['command'][1:]],environment=slot['environment'],exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr))
 validate_outcomes(row,successful=False)
outcomes=aggregate(rows)
assert len(outcomes['scheduled_ids'])==63
assert len(outcomes['executed_ids'])==len(outcomes['passed_ids'])==49
assert len(outcomes['unexecuted_ids'])==14
assert len(outcomes['suite_errors'])==2
for row in rows:
 if row['errors']:
  try:validate_outcomes(row)
  except ValueError:pass
  else:raise AssertionError('Setup failure accepted')
(B/'real-negative-setup.json').write_text(json.dumps(dict(reviewed_parent='bf5a5a626f6a08458ba59c8b0313b4745c45d07d',disposable_negative_source=sha,scope='five historical remediation suites only; no full regression',outcomes=outcomes,rows=rows,logs=logs),indent=2)+'\n')
print(json.dumps(dict(scheduled=63,executed=49,passed=49,unexecuted=14,suite_setup_errors=2)))
